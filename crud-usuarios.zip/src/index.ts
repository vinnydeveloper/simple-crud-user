import App from "./infra/App";

const app = new App();

app.setup({ port: 4000 });
