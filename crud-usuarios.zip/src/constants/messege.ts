const MESSEGES = {
  default: "Deu ruim , chama o suporte",
};
