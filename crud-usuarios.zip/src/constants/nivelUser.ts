const NIVEL_USER = {
  ADMIN: 0,
  USER: 1,
};

export default NIVEL_USER;
